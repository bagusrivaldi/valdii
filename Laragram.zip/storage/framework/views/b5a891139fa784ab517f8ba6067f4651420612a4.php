<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
</head>
<body class="bg-gray-100 h-screen antialiased leading-none font-sans">
    <div id="app">        
        <nav class="flex items-center justify-around flex-wrap bg-white p-4 shadow-md">
            <div class="flex items-center flex-shrink-0 text-gray-800 mr-6 cursor-pointer">
                <img src="<?php echo e(asset('image/logo.png')); ?>" width="50px" alt="<?php echo e(config('app.name', 'Laravel')); ?>">
            </div>
            <div>
                <?php if(auth()->guard()->guest()): ?>
                    <a class="no-underline hover:underline px-1" href="<?php echo e(route('login')); ?>">Login</a>
                    <a class="no-underline hover:underline px-1" href="<?php echo e(route('register')); ?>">Register</a>
                <?php else: ?>
                    <a class="no-underline hover:underline px-1" href="/profile/<?php echo e(auth()->user()->id); ?>">Profile</a>
                    <a href="<?php echo e(route('logout')); ?>"
                        class="no-underline hover:underline px-1"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                        <?php echo e(csrf_field()); ?>

                    </form>
                <?php endif; ?>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\instax\Laragram\resources\views/layouts/app.blade.php ENDPATH**/ ?>