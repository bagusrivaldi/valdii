

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto my-10 sm:px-20 flex justify-center">
        <div class=" rounded overflow-hidden border w-full lg:w-6/12 md:w-6/12 bg-white mx-3 md:mx-0 lg:mx-0">
            <div class="w-full flex justify-between p-3">
                <div class="flex">
                    <div class="rounded-full h-8 w-8 bg-gray-500 flex items-center justify-center overflow-hidden">
                        <img src="<?php echo e($post->user->profile->profile_image()); ?>" alt="profile_image">
                    </div>
                    <span class="pt-1 ml-2 font-bold text-sm"><?php echo e($post->user->username); ?></span>
                </div>
                <span class="px-2 hover:bg-gray-300 cursor-pointer rounded"><i class="fas fa-ellipsis-h pt-2 text-lg"></i></span>
            </div>

            <img class="w-full bg-cover" src="/storage/<?php echo e($post->image); ?>">
            <div class="px-3 pb-2">
                <div class="pt-2">
                    <i class="far fa-heart cursor-pointer"></i>
                    <span class="text-sm text-gray-400 font-medium">Description</span>
                </div>
                <div class="pt-1">
                    <div class="mb-2 text-sm"><?php echo e($post->description); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\instax\Laragram\resources\views/post/show.blade.php ENDPATH**/ ?>