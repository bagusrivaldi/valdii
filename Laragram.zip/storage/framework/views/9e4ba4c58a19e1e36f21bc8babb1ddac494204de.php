

<?php $__env->startSection('content'); ?>

<div class="py-20">
    <div class="max-w-md mx-auto bg-white overflow-hidden md:max-w-lg shadow-lg">
        <div class="md:flex">
            <div class="w-full px-4 py-6">
                <?php if($errors->any()): ?>
                    <div class="bg-gradient-to-r from-blue-400 to-blue-600 p-4 flex items-start text-white my-4 shadow-lg mx-auto max-w-2xl">
                        <div class="px-3">
                            <ul class="list-disc list-inside">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?>.</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data" action="/profile/<?php echo e(auth()->user()->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                    <div class="mb-6">
                        <label for="title" class="block mb-2 text-sm text-gray-600">Title</label>
                        <input
                            class="w-full px-3 py-2 focus:outline-none bg-white-100 border border-bg-blue-500 focus:outline-none focus:border-blue-500"
                            type="text"
                            name="title"
                            value="<?php echo e(auth()->user()->profile->title); ?>"
                            placeholder="Enter a title."
                        />
                    </div>
                    <div class="mb-6">
                        <label for="description" class="block mb-2 text-sm text-gray-600">Description</label>
                        <textarea
                            class="w-full px-3 py-2 focus:outline-none bg-white-100 border border-bg-blue-500 focus:outline-none focus:border-blue-500"
                            type="text"
                            name="description"
                            rows="4" cols="50"
                        ><?php echo e(auth()->user()->profile->description); ?></textarea>
                    </div>
                    <div class="mb-6">
                        <label for="image" class="block mb-2 text-sm text-gray-600">Image</label>
                        <div class="relative border-dotted h-32 border-dashed border-2 border-blue-500 bg-gray-100 flex justify-center items-center">
                            <div class="absolute">
                                <div class="flex flex-col items-center"> 
                                    <span class="block text-gray-400 font-normal">Attach a photo here</span>
                                </div>
                            </div> 
                            <input type="file" name="image" class="h-full w-full opacity-0" name="">
                        </div>
                    </div>
                    
                    <div class="mt-3 text-right"> 
                        <a href="/profile/<?php echo e(auth()->user()->id); ?>">Cancel</a> 
                        <button class="ml-2 h-10 w-32 bg-blue-500 text-white hover:bg-blue-700">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\instax\Laragram\resources\views/profile/edit.blade.php ENDPATH**/ ?>