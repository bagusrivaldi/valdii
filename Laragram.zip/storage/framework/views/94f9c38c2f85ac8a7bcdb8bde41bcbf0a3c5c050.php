

<?php $__env->startSection('content'); ?>
    <main class="bg-gray-100 bg-opacity-25">
        <div class="lg:w-8/12 lg:mx-auto mb-8">
            <header class="flex flex-wrap items-center p-4 md:py-8">

                <div class="md:w-3/12 md:ml-16">
                    <img class="w-20 h-20 md:w-40 md:h-40 object-cover rounded-full" width="50px" src=<?php echo e($user->profile->profile_image()); ?> alt="profile">
                </div>

                <div class="w-8/12 md:w-7/12 ml-4">
                    <div class="md:flex md:flex-wrap md:items-center mb-4">
                        <h2 class="text-3xl inline-block font-light md:mr-2 mb-2 sm:mb-0">
                            <?php echo e($user->username); ?>

                        </h2>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user->profile)): ?>
                            
                            <a href="/profile/<?php echo e($user->id); ?>/edit" class="
                                focus:outline-none text-white font-semibold text-sm rounded-md text-center
                                sm:inline-block block bg-blue-500 hover:shadow-md px-4 py-2 mt-2 ml-2"
                            >
                                Edit Profile
                            </a>
                        <?php endif; ?>
                    </div>

                    <ul class="hidden md:flex space-x-8 mb-4">
                        <li><span class="font-semibold"><?php echo e($user->posts->count()); ?></span> posts</li></ul>

                    <div class="hidden md:block">
                        <h1 class="font-semibold"><?php echo e($user->profile->title ?? 'No title...'); ?></h1>
                        <p><?php echo e($user->profile->description ?? 'No description...'); ?></p>
                    </div>
                </div>

                <div class="md:hidden text-sm my-2">
                    <h1 class="font-semibold"><?php echo e($user->profile->title); ?></h1>
                    <p><?php echo e($user->profile->description); ?></p>
                </div>
            </header>

            <div class="px-px md:px-3">
                <ul class="flex md:hidden justify-around space-x-8 border-t text-center p-2 text-gray-600 leading-snug text-sm">
                    <li><span class="font-semibold text-gray-800 block"><?php echo e($user->posts->count()); ?></span> posts</li>
                    <li><span class="font-semibold text-gray-800 block"><?php echo e($user->profile->created_at->diffForHumans()); ?></span> created</li>
                    <li><span class="font-semibold text-gray-800 block"><?php echo e($user->profile->updated_at->diffForHumans()); ?></span> updated</li>
                </ul>

                <div class="flex flex-wrap -mx-px md:-mx-3">
                    <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w-1/3 p-px md:px-3">
                            <a href="/post/<?php echo e($post->id); ?>">
                                <article class="post bg-gray-100 text-white relative pb-full md:mb-6">
                                    <img class="w-full h-full absolute left-0 top-0 object-cover" src="/storage/<?php echo e($post->image); ?>" alt="image">
                                </article>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\instax\Laragram\resources\views/profile/show.blade.php ENDPATH**/ ?>